﻿using System;

namespace Lesson5_值类型和引用类型
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            #region 变量类型
            //无符号整型
            byte b = 1;
            ushort us = 1;
            uint ui = 1;
            ulong ul = 1;
            //有符号整型
            sbyte sb = 1;
            short s = 1;
            int i = 1;
            long l = 1;
            //浮点数
            float f = 1f;
            double d = 1.1;
            decimal de = 1.1m;
            //特殊类型
            bool bo = true;
            char c = 'A';
            string str = "string";
            //复杂数据类型
            //枚举 enum
            //数组

            //分类：
            //引用类型：string，数组，类
            //值类型：其他所有，结构体
            #endregion

            #region 区别
            //1.使用上的区别
            //值类型
            int a = 10;
            //引用类型
            int[] arr = new int[] { 1, 2, 3, 4 };

            //申明一个aa让其等于之前的a
            int aa = a;
            //申明一个arr2让其等于之前的arr
            int[] arr2 = arr;
            Console.WriteLine("a={0},aa={1}",a,aa);
            Console.WriteLine("arr={0},arr2={1}",arr[0],arr2[0]);

            aa = 20;
            arr[0] = 5;
            Console.WriteLine("修改了a和arr[0]之后");
            Console.WriteLine("a={0},aa={1}",a,aa);
            Console.WriteLine("arr={0},arr2={1}",arr[0],arr2[0]);
            
            //值类型在相互赋值时 将内容相互拷贝给对方
            //引用类型的互相赋值 是让 两者指向同一个值，它变我也变
            
            //为什么有区别
            //因为存储方式不同
            //值类型存储在 栈空间--系统分，自动回收，小而快
            //引用类型存储在 堆空间--手动申请和释放，大而慢
             //使用new关键字
            #endregion
        }
    }
}