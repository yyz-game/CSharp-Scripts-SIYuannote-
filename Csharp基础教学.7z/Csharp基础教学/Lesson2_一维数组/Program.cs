﻿using System;

namespace Lesson2_一维数组
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            //一维数组简称数组

            #region 数组的申明
            //1.变量类型[] 数组名；//只申明了数组 但是没有开房
            //变量类型 可以是我们学过的 或者 没学过的所有变量类型
            int[] arr1;
            
            //2.变量类型[] 数组名 = new 变量类型[数组长度];
            int[] arr2 = new int[5];//房间为5 int值默认为0
            
            //3.变量类型[] 数组名 = new 变量类型[数组长度]{内容1,内容2,内容3};
            int[] arr3 = new int[5] { 1, 2, 3, 4, 5 };//要填够

            //4.变量类型[] 数组名 = new 变量类型[]{内容1,内容2,内容3};
            int[] arr4 = new[] { 5, 6, 7, 8, 9 };//数组内容决定房间数

            //5.变量类型[] 数组名 ={内容1,内容2,内容3};
            int[] arr5 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

            #endregion

            #region 数组的使用

            int[] array = { 1, 2, 3, 4, 5 };
            //数组的长度：
            //数组变量名.Length
            Console.WriteLine(array.Length);
            
            //获取数组的元素：
            //数组的下标和索引从0开始
            //通过索引下标获取数组元素时 不能越界
            Console.WriteLine(array[0]);//1
            Console.WriteLine(array[4]);//5
            
            //修改数组中的元素：数组变量名[索引]=修改值
            //同一类型
            array[0] = 99;
            Console.WriteLine(array[0]);//99

            //遍历数组：使用for循环
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }
            
            //增加数组的元素：
            //初始化后不能 直接 添加新元素
            //使用for搬家
            int[] array2 = new int[6];
            for (int i = 0; i < array.Length; i++)
            {
                array2[i] = array[i];
            }
            array = array2;//使原有数组等于现有数组
            
            //删除数组的元素：初始化后不能直接删除，使用for搬家
            int[] array3 = new int[5];
            for (int i = 0; i < array3.Length; i++)
            {
                array3[i] = array[i];
            }
            array = array3;
            
            //查找数组中的元素：使用for遍历查找
            //只有遍历才可以确定
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] == 3)
                {
                    Console.WriteLine("有，在第{0}个位置",i);
                }
            }
            
            #endregion

            #region 特殊引用类型string(它变我不变)

            string str1 = "123";
            string str2 = str1;
            //因为string具备值类型的特征(它变我不变)
            //在赋值后，会在堆中创建新的地址
            //string方便但是频繁的改变string，会造成内存垃圾

            #endregion
        }
    }
}