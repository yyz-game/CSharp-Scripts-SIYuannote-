﻿namespace Lesson9_函数重载
{
    internal class Program
    {
        #region 实例
        //1.重载与返回值类型无关，只和参数类型，个数，顺序有关
        //2.调用时 程序会自己根据传入的参数类型判断使用哪一个重载
        //初始函数
        static int CalcSum(int a, int b)
        {
            return a + b;
        }
            
        //参数数量不同
        static int CalcSum(int a, int b, int c)
        {
            return a + b + c;
        }
        
        //数量相同 类型不同
        static float CalcSum(float a, int b)
        {
            return a + b;
        }
        
        //ref和out
        //不能两个一起重载
        static float CalcSum( ref float a, int b)//out
        {
            return a + b;
        }
        
        //变长参数
        static float CalcSum(float a, params int[] b)
        {
            return 1;
        }
        //默认值可选参数不可以重载

        #endregion
        public static void Main(string[] args)
        {
            //参数数量不同
            CalcSum(1, 2);
            CalcSum(1, 2, 3);
            //数量相同 类型不同
            CalcSum(1.1f, 2);
        }
    }
}