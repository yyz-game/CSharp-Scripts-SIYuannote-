﻿using System;

namespace Lesson7_ref和out
{
    internal class Program
    {
        #region 学习ref和out的原因
        //解决在函数内部变外部传入的内容 
        //里面变了 外面也要变
        static void ChangeValue(int value)
        {
            value = 3;//值类型
        }

        static void ChangeArrayValue(int[] array)
        {
            array[0] = 99;//引用类型
        }

        static void ChangeArray(int[] arr)
        {
            arr = new int[] { 10, 20 };
        }
        #endregion

        #region ref和out的使用
        //函数参数的修饰符
        //当传入的值类型参数在内部修改时 或者引用类型参数在内部重新申明时
        //外部的值会发生变化

        //ref的使用
        static void ChangeValueRef(ref int value)
        {
            value = 3;
        }

        static void ChangeArrayRef(ref int[] arr)
        {
            arr = new int[] { 100, 200 };
        }
        
        //out的使用
        static void ChangeValueOut(out int value)
        {
            value = 4;
        }
        static void ChangeArrayOut(out int[] arr)
        {
            arr = new int[] { 999, 888 };
        }
        #endregion
        
        public static void Main(string[] args)
        {
            #region ref和out的区别
            //1.ref传入的变量必须初始化 out不用
            //2.out传入的变量必须在内部赋值 ref不用
            int c = 1;
            ChangeValueRef(ref c);//若只是int c而不初始化赋值 那么会报错
            ChangeValueOut(out c);
            
            //ref因为在外部初始化过了,可以不用内部赋值
            //out因为在外部没有初始化,必须内部赋值(不管是否外部初始化,必须内部赋值)
            #endregion
            //学习ref和out的原因
            int a = 1;
            ChangeValue(a);//值类型
            Console.WriteLine(a);//输出还是1,而不是3

            int[] arr2 = { 1, 2 };
            ChangeArrayValue(arr2);//引用类型
            Console.WriteLine(arr2[0]);//输出是99而不是2

            ChangeArray(arr2);
            Console.WriteLine(arr2[0]);//因为new 新创建房间
            
            //ref和out的使用
            Console.WriteLine("ref的使用");
            ChangeValueRef(ref a);
            Console.WriteLine(a);//输出是3
            ChangeValueOut(out a);
            Console.WriteLine(a);//输出是4
            
            ChangeArrayRef(ref arr2);
            Console.WriteLine(arr2[0]);//输出为100
            ChangeArrayOut(out arr2);
            Console.WriteLine(arr2[0]);//输出为999
            
        }
    }
}