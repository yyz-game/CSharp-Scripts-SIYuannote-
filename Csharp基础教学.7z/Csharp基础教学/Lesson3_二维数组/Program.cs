﻿using System;

namespace Lesson3_二维数组
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("二维数组");

            #region 知识点一 基本概念
            //二维数组是使用两个下标来确定元素的数组
            //分为 行标 和 列标
            //比如矩阵 1 2 3
            //        5 6 7
            //可以用int[2,3]表示 两行 三列

            #endregion

            #region 二维数组的申明
            //变量类型[,] 二维数组变量名；
            //例如：
            int[,] arr;//数组要初始化
            
            //变量类型[,] 二维数组变量名 = new 变量类型[行,列]；
            int[,] arr2 = new int[3, 3];

            //变量类型[,] 二维数组变量名 = new 变量类型[行,列]{{0行内容1,0行内容2}，{1行内容1,1行内容2}}；
            int[,] arr3 = new int[3, 3]
            {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 },
            };

            //变量类型[,] 二维数组变量名 = new 变量类型[,]{{0行内容1,0行内容2}，{1行内容1,1行内容2}}；
            int[,] arr4 = new int[,]
            {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 },
            };

            //变量类型[,] 二维数组变量名 ={{0行内容1,0行内容2}，{1行内容1,1行内容2}}；
            int[,] arr5 =
            {
                { 1, 2, 3 },
                { 4, 5, 6 },
                { 7, 8, 9 },
            };
            #endregion

            #region 二维数组的使用

            int[,] array = new int[,]
            {
                { 1, 2, 3 },
                { 4, 5, 6 },
            };
            //1.长度：要获取行和列
            //变量名.GetLength(0)//行
            //变量名.GetLength(1)//列
            //得到行
            Console.WriteLine(array.GetLength(0));
            //得到列
            Console.WriteLine(array.GetLength(1));
            
            //2.获取元素
            Console.WriteLine(array[0,1]);//2
            Console.WriteLine(array[1,2]);//6
            //3.修改：先得到再赋值
            array[0, 0] = 99;//修改为99
            
            //4.遍历：for循环
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array.GetLength(1); j++)
                {
                    //i是行 j是列
                    Console.WriteLine(array[i,j]);
                }
            }
            
            //5.增加：for循环搬家
            
            
            //6.删除：for循环搬家
            
            
            //7.查找：for循环


            #endregion
        }
    }
}