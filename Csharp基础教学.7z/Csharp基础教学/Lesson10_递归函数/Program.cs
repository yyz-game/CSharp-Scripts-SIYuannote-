﻿using System;

namespace Lesson10_递归函数
{
    internal class Program
    {
        #region 实例
        //用递归函数 打印出0-10
        static void DaYing(int a)
        {
            Console.WriteLine(a);
            a = a + 1;
            if (a > 10)
            {
                return;
            }
            DaYing(a);
        }
        

        #endregion
        public static void Main(string[] args)
        {
            DaYing(0);
        }
    }
}