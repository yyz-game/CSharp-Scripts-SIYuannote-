﻿using System;

namespace Lesson1_枚举
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("枚举");
            
            #region 知识点三 枚举的使用
            //申明枚举变量
            //自定义的枚举类型 变量名 = 默认值；(自定义的枚举类型.枚举项)
            E_MonstterType monstterType = E_MonstterType.Normal;
            if (monstterType == E_MonstterType.Boss)
            {
                //Boss逻辑
            }
            if (monstterType == E_MonstterType.Normal)
            {
                //Normal逻辑
            }
            //枚举和switch一对
            switch (monstterType)
            {
                case E_MonstterType.Normal:
                    break;
                case E_MonstterType.Boss:
                    break;
            }
            #endregion
            
            #region 知识点四 枚举的类型转换
            //1.枚举和int
            int i = (int)monstterType;//括号强转
            Console.WriteLine(i);//0
            //int转枚举
            monstterType = 0;
            //2.枚举和string
            string str = monstterType.ToString();
            Console.WriteLine(str);//打印的为枚举项的名字
            //string转枚举
            monstterType = (E_MonstterType)Enum.Parse(typeof(E_MonstterType), "Boss");
            Console.WriteLine(monstterType);
            #endregion
        }
    }
    #region 知识点一 基本概念

    #region 1.枚举是什么
    //被命名 的 整型常量 的 集合
    //一般用它来表示 状态 类型 等等
    #endregion

    #region 2.申明枚举 和 申明枚举变量
    //注意：两个概念
    //申明枚举：相当于 创建一个自定义的枚举类型
    //申明枚举变量：使用申明的自定义枚举类型 创建一个枚举变量
    #endregion

    #region 3.申明枚举的语法
    //枚举名 以E或者E_开头 作为我们的命名规范
    /*
    enum E_自定义枚举名
    {
        自定义枚举项名字, //枚举中包裹的 整形常量 第一个默认为0 依次累加
        自定义枚举项名字1,
        自定义枚举项名字2,
        自定义枚举项名字3 = 500,//从500开始累加
    }
    */
    #endregion
    #endregion
    
    #region 知识点二 在哪里申明枚举
    //1.namespace语句块中(常用)
    //2.class语句块中 struct语句块中
    //枚举不能在函数语句块中申明
    enum E_MonstterType
    {
        Normal,//0
        Boss,//1
    }
    #endregion
    
    #region 知识点五 枚举的作用
    //在游戏开发中，对象会有很多的状态
    //比如玩家 有很多的动作状态 
    //综合考虑可以使用int来表示状态 但是 使用int若无注释 不方便阅读
    
    //枚举可以清晰的分清楚状态 提升可读性
    #endregion
}