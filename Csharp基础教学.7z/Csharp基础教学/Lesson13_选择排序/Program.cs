﻿using System;

namespace Lesson13_选择排序
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            #region 代码实现
            int[] a = { 8, 7, 1, 5, 4, 2, 6, 3, 9 };

            for (int m = 0; m < a.Length; m++)
            {
                //申明中间商 默认第一个为极值
                int index = 0;
                //第二部
                for (int i = 1; i < a.Length - m; i++)//-m是为了排除已经放好位置的数
                {
                    //找出极值
                    if (a[index] < a[i])
                    {
                        index = i;
                    }
                }

                //放入目标位置
                //length - 1 - 轮数
                if (index != a.Length - 1 - m)
                {
                    int temp = a[index];
                    a[index] = a[a.Length - 1 - m];
                    a[a.Length - 1 - m] = temp;
                }
            }
            
            
            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + " ");
            }

            #endregion
        }
    }
}