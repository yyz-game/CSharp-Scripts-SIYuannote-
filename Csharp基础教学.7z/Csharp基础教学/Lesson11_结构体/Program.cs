﻿using System;

namespace Lesson11_结构体
{
    #region 基本语法
    //结构体一般写在namespace语句块中
    //结构体的关键字struct
    struct 自定义结构体名
    {
        //第一部分:变量
        
        //第二部分:构造函数
        
        //第三部分:函数
    }
    #endregion

    #region 实例
    //用结构体表现学生数据
    struct Student
    {
        //变量:
        //结构体申明的变量 不能直接初始化 使用构造函数初始化
        //变量类型可以是结构体 但是不能是自己
        
        //年龄
        public int age;
        //性别 是否男性
        public bool sex;
        //姓名
        public string name;
        
        //构造函数
        #region 构造函数
        //1.没有返回值
        //2.函数名必须与结构体同名
        //3.必须有参数
        //4.如果申明构造函数,那么必须在其中对所有变量进行初始化

        public Student(int age,bool sex,string name)
        {
            //关键字this 代表自己
            this.age = age;
            this.name = name;
            this.sex = sex;
        }
        #endregion

        //函数
        //表现这个数据结构的行为
        //注意:结构体中的方法目前不需要static关键字

        public void Speak()
        {
            //在函数中可以直接使用结构体内部申明的变量
            Console.WriteLine("我的名字是{0},我今年{1}岁",name,age);
        }
        
    }

    #endregion
    
    internal class Program
    {

        public static void Main(string[] args)
        {
            #region 结构体的使用
            //结构体是自定义变量类型
            //未使用构造函数
            Student s1;
            s1.name = "Ze";
            s1.age = 18;
            s1.sex = true;
            s1.Speak();
            
            //使用构造函数
            //在构造函数中使用过,所以可以直接使用
            Student s2 = new Student(18, true, "ze");

            #endregion

        }
    }
}