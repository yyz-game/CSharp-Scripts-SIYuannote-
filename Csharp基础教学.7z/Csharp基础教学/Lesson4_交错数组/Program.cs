﻿using System;

namespace Lesson4_交错数组
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            #region 基本概念
            //交错数组 是 数组的数组 每个维度的数量可以不同
            #endregion

            #region 数组的申明
            //变量类型 [][] 交错数组名
            int[][] arr1;
            
            //变量类型 [][] 交错数组名 = new 变量类型[行数][]；
            int[][] arr2 = new int[3][];//列需要空出来

            //变量类型 [][] 交错数组名 = new 变量类型[行数][]{一维数组1，一维数组2}；
            int[][] arr3 = new int[3][]
            {
                new int[] { 1, 2, 3 },
                new int[] { 1, 2 },
                new int[] { 5 },
            };
            //变量类型 [][] 交错数组名 = {一维数组1，一维数组2}；
            int[][] arr4 =
            {
                new int[] { 1, 2, 3 },
                new int[] { 7, 8 },
                new int[] { 5 },
            };

            #endregion

            #region 数组的使用
            int[][] array =
            {
                new int[] { 1, 2, 3 },
                new int[] { 7, 8 },
            };
            //1.长度获取
            Console.WriteLine(array.GetLength(0));
            Console.WriteLine(array[0].Length);//得到某一行的列数
            
            //2.获取元素
            Console.WriteLine(array[0][1]);//2
            
            //3.修改：先得到再赋值
            array[0][1] = 99;
            
            //4.遍历：for循环
            for (int i = 0; i < array.GetLength(0); i++)
            {
                for (int j = 0; j < array[i].Length; j++)
                {
                    Console.Write(array[i][j] + " ");
                }
                Console.WriteLine();
            }
            //5.增加：for循环搬家
            //6.删除：for循环搬家
            //7.查找：for循环


            #endregion
        }
    }
}