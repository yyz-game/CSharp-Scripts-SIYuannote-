﻿using System;

namespace Lesson8_变长参数和参数默认值
{
    internal class Program
    {
        #region 变长参数关键字
        //举例 函数要计算n个整数的和
        //static int Sum(int a ,int b,.....)
        
        //params关键字
        static int Sum(params int[] arr)//params关键字后必须为数组 可以是任意类型
        {
            //params 类型[]意味着可以传入n个参数 n可以等于0，传入的参数会存在数组中
            int sum = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }
            return sum;
        }
        //多个函数参数，params变长参数在最后，且只能有一个
        static void Eat(string name, params int[] age)
        {
            
        }
        #endregion

        #region 参数默认值
        //有参数默认值的参数，被称为可选参数
        //作用：当调用函数时可以不传入参数,不传就会使用默认值作为参数的值
        static void Speak(string str = "参数默认值")
        {
            Console.WriteLine(str);
        }
        //注意：
        //1.支持多参数默认值
        //2.如果要混用，可选参数必须在普通参数后面
        static void Speak2(string str, string name = "Ze")
        {
            Console.WriteLine(str);
            Console.WriteLine(name);
        }

        #endregion
        public static void Main(string[] args)
        {
            //params
            Sum(1, 2, 3, 4, 5, 6, 7);
            
            //参数默认值
            Speak();
            Speak("我不是参数默认值");
            
            Speak2("1","2");
        }
    }
}