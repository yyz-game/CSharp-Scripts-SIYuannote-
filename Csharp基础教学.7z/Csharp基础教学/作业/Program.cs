﻿using System;
using System.Security.Policy;

namespace 作业
{
    struct Player
    {
        public string player;
        public string jineng;
        public string zhiye;

        public void Speak()
        {
            string a;
            string read;
            
            Console.WriteLine("选择你的职业,输入a为战士,b为猎人,c为法师");
            a = Console.ReadLine();
            Console.WriteLine("输入你的姓名");
            read = Console.ReadLine();
            
            switch (a)
            {
                case "a":
                    zhiye = "战士";
                    jineng = "冲锋";
                    break;
                case "b":
                    zhiye = "猎人";
                    jineng = "假死";
                    break;
                case "c":
                    zhiye = "法师";
                    jineng = "奥术冲击";
                    break;
                default:  
                    Console.WriteLine("无效的职业选择");  
                    return;
            }
            Console.WriteLine("{0}{1}释放了{2}",zhiye,read,jineng);
        }
        
    }
    internal class Program
    {
       
        public static void Main(string[] args)
        {
            Player p = new Player();
            p.Speak();
        }
    }
}