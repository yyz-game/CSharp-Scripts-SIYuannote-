﻿using System;

namespace Lesson12_冒泡排序
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            #region 基本原理
            //两两相邻
            //不停比较
            //不停交换
            //比较n轮
            #endregion

            #region 代码实现
            //第一步:如何比较数组中两两相邻的数
            //8,7,1,5,4,2,6,3,9
            int[] a = { 8, 7, 1, 5, 4, 2, 6, 3, 9 };
            int b;
            int c = 0 ;
            
            //从n开始
            for (int i = 0;i < a.Length - 1;i++)
            {
                //交换位置
                if (a[i] > a[i+1])
                {
                    b = a[i];
                    a[i] = a[i + 1];
                    a[i + 1] = b;
                    i = - 1;//重置为-1,因为有i++存在,要使i进入if为0
                }
            }

            for (int i = 0; i < a.Length; i++)
            {
                Console.Write(a[i] + " ");
            }

            #endregion
        }
    }
}