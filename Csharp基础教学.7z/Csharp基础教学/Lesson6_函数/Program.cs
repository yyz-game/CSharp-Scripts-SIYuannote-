﻿using System;

namespace Lesson6_函数
{
    internal class Program
    {
        #region 1.基本概念
        /*函数(方法)
         *本质是一块具有名称来执行该代码块
         * 可以使用函数(方法)的名称来执行该代码块
         *函数(方法)是封装代码进行重复使用的一种机制
         */
            
        /*函数(方法)的主要作用
         * 1.封装代码、
         * 2.提升代码复用率
         * 3.抽象行为
         */
        #endregion
            
        #region 2.函数写在哪
        //1.class(类)语句块中
        //2.struct(结构体)语句块中
        #endregion
            
        #region 3.基本语法
        /*  1      2       3                 4
         static 返回类型 函数名(参数类型 参数名1，参数类型 参数名2......)
        {
            函数代码逻辑;
            ...........
                5
            return 返回值;(有返回类型才返回)
        }
        */
            
        //1.关于static 不是必须的
        //2-1.返回类型 引出新的关键字 void1(表示没有返回值)
        //2-2.返回类型 可以写任意的变量类型 14种变量类型 + 复杂数据类型
        //3.关于函数名 帕斯卡命名法 myName(驼峰) MyName(帕斯卡)
        //4-1.参数不是必须的 可以有0-n个参数
        //4-2.参数名 驼峰命名法
        //5.当返回值类型不为void时 必须通过新的关键词 return返回对应类型的内容(注意：即使是void也可以选择使用return)
        #endregion

        #region 4.实际运用
        //1.无参无返回值函数
        static void SayHellow()
        {
                Console.WriteLine("你好世界");
                //没有返回值,return可以省略
                //return;
        }
            
        //2.有参无返回值函数
        static void SayYourName(string name)
        {
            Console.WriteLine("你的名字是:{0}",name);
        }
        
        //3.无参有返回值函数
        static string WhatYourName()
        {
            return "Ze";//是string,就得返回string类型
        }
        
        //4.有参有返回值函数
        static int YouYear(int a,int b)
        {
            Console.WriteLine("你的年龄是{0}",a);
            Console.WriteLine("我的年龄是{0}",b);
            return a + b;
        }
        
        //5.有参数有多个返回值类型
        //传入两个数,计算两个数的和 和 平均数 得出结果
        //函数的返回值 一个类型只能是一个内容
        static int[] HePingJun(int a,int b)
        {
            int sum = a + b;
            int avg = sum / 2;
            return new int[]{ sum, avg };
        }
        #endregion
            
        #region 5.关于return
        //即使函数没有返回值 也可以使用return,
        //return可以直接不执行之后的代码 直接返回到函数外部
        static string Speak(string str)
        {
            if (str == "混蛋")
            {
                return " ";
            }
            return str;
        }

        #endregion
        public static void Main(string[] args)
        {
            #region 4.实际使用 例子
            Console.WriteLine("函数");
            //直接调用
            SayHellow();
           
            //传入的参数可以是常量变量 要是对应类型
            //传入一个string常量
            SayYourName("Ze");
            //传入一个string变量
            string str = "ZeZe";
            SayYourName(str);
           
            //在Console中传一个string常量函数
            SayYourName(WhatYourName());
            //有返回值的函数 一般会拿来直接用
            //或者拿变量 接受结果
            string str2 = WhatYourName();
           
            //传入
            int c = YouYear(18,15);
            Console.WriteLine("我们一共{0}岁",c);
           
            //求和 平均数
            int[] i = HePingJun(55,25);
            Console.WriteLine("和为{0},平均数为{1}",i[0],i[1]);
            #endregion
        }
    }
}